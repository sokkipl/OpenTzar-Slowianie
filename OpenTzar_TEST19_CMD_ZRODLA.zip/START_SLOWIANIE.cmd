@echo off
setlocal
cd /d "%~dp0"
if exist "OpenTzar.exe" goto play
where rustup >nul 2>&1
if not errorlevel 1 (set "RUSTUP=rustup") else (set "RUSTUP=%USERPROFILE%\.cargo\bin\rustup.exe")
if not exist "%USERPROFILE%\.cargo\bin\rustup.exe" if not "%RUSTUP%"=="rustup" goto missing
set "CARGO_TERM_COLOR=never"
set "CARGO_PROFILE_RELEASE_LTO=false"
set "CARGO_PROFILE_RELEASE_CODEGEN_UNITS=16"
set "CARGO_PROFILE_RELEASE_OPT_LEVEL=1"
set "CARGO_PROFILE_RELEASE_INCREMENTAL=true"
set "CARGO_PROFILE_RELEASE_STRIP=none"
if not defined CARGO_TARGET_DIR set "CARGO_TARGET_DIR=%CD%\cache-test"
echo [TEST19] Jednorazowa kompilacja. Internet i Rust/MSVC sa wymagane.
pushd "%~dp0src"
"%RUSTUP%" run 1.99.0-x86_64-pc-windows-msvc cargo build --locked --release --jobs 1 --bin retzar >"%~dp0KOMPILACJA.txt" 2>&1
set "RESULT=%errorlevel%"
popd
if not "%RESULT%"=="0" goto buildfail
copy /y "%CARGO_TARGET_DIR%\release\retzar.exe" "%~dp0OpenTzar.exe" >nul
if errorlevel 1 goto buildfail
start "" /wait "%~dp0OpenTzar.exe" --ot-check-assets >"%~dp0KONTROLA_ZASOBOW.txt" 2>&1
if errorlevel 1 goto checkfail
:play
if not exist "runtime-art-v1.ok" (
  start "" /wait "%~dp0OpenTzar.exe" --ot-check-assets >"%~dp0KONTROLA_ZASOBOW.txt" 2>&1
  if errorlevel 1 goto checkfail
)
echo [TEST19] Uruchamianie gry...
start "" /wait "%~dp0OpenTzar.exe" --root "%~dp0." --skip-intro --screen Random >"%~dp0OpenTzar-konsola.txt" 2>&1
set "RESULT=%errorlevel%"
if not "%RESULT%"=="0" start "" notepad "%~dp0OpenTzar-konsola.txt"
exit /b %RESULT%
:missing
echo Brak rustup. Zainstaluj Rust oraz Visual Studio Build Tools (C++), potem sprobuj ponownie.
pause
exit /b 1
:buildfail
echo Kompilacja nie powiodla sie. Sprawdz KOMPILACJA.txt.
if exist "%~dp0KOMPILACJA.txt" start "" notepad "%~dp0KOMPILACJA.txt"
pause
exit /b 1
:checkfail
echo Kontrola zasobow nie powiodla sie. Sprawdz runtime-art-v1.error.
if exist "%~dp0runtime-art-v1.error" start "" notepad "%~dp0runtime-art-v1.error"
pause
exit /b 1
