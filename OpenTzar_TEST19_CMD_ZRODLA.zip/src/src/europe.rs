//! European sheets from the player's unmodified Polish GOG picture archive.
//! The active installation remains the source of the Slavic artwork.
use crate::{Result, archive, archive::Archive, invalid};
use std::{collections::HashMap, fs, io::Read, path::{Path, PathBuf}, sync::OnceLock};

const GOG_SIZE: usize = 62145886;
const GOG_CRC: u32 = 0xb5998b64;
static PICTURES: OnceLock<HashMap<String, Vec<u8>>> = OnceLock::new();

pub fn ready() -> bool { PICTURES.get().is_some() }

pub fn picture(path: &str) -> Option<&'static [u8]> {
    if !path.as_bytes().get(..15).is_some_and(|p| p.eq_ignore_ascii_case(b"IMAGES/EU_BASE/")) { return None; }
    let key = archive::key(path);
    let relative = key.strip_prefix("IMAGES/EU_BASE/")?;
    PICTURES.get()?.get(relative).map(Vec::as_slice)
}

fn original_bytes(path: &Path) -> Result<Vec<u8>> {
    let zip = path.extension().is_some_and(|s| s.eq_ignore_ascii_case("zip"));
    let data = if zip {
        let mut archive = zip::ZipArchive::new(fs::File::open(path)?)?;
        let index = archive.file_names().position(|n| {
            let k = archive::key(n);
            k == "PACKS/IMAGES.WDT" || k == "IMAGES.WDT"
        }).ok_or("Brak Packs/images.wdt w ZIP")?;
        let file = archive.by_index(index)?;
        if file.size() != GOG_SIZE as u64 { return Err(invalid("Inna wersja images.wdt")); }
        let mut data = Vec::with_capacity(GOG_SIZE);
        file.take(GOG_SIZE as u64 + 1).read_to_end(&mut data)?;
        data
    } else {
        if fs::metadata(path)?.len() != GOG_SIZE as u64 { return Err(invalid("Inna wersja images.wdt")); }
        fs::read(path)?
    };
    if data.len() != GOG_SIZE || crc32fast::hash(&data) != GOG_CRC {
        return Err(invalid("Wymagane są oryginalne grafiki europejskie z polskiej wersji GOG"));
    }
    Ok(data)
}

fn candidates(dir: &Path) -> impl Iterator<Item=PathBuf> {
    ["images.wdt", "Packs/images.wdt", "Packs.zip"].into_iter().map(|name|dir.join(name))
}

pub fn prepare(source: &Path, root: &Path) -> Result<()> {
    if PICTURES.get().is_some() { return Ok(()); }
    let config = root.join("Europa-zrodlo.txt");
    let mut paths: Vec<_> = fs::read_to_string(&config).ok().map(PathBuf::from).into_iter().collect();
    paths.extend(candidates(source));
    paths.extend(candidates(root));
    if let Some(home) = std::env::var_os("USERPROFILE") {
        paths.extend(candidates(&PathBuf::from(home).join("Downloads")));
    }
    let locate = |paths: Vec<PathBuf>| paths.into_iter().find_map(|path| original_bytes(&path).ok().map(|b|(path,b)));
    let (path, bytes) = match locate(paths) {
        Some(pair) => pair,
        None => {
            let dir = crate::picker::folder("Grafiki Europy: wybierz folder z oryginalnym images.wdt lub Packs.zip (polski GOG)", Some(root))
                .ok_or("Nie wskazano kopii oryginalnych grafik Europy. Włóż oryginalny images.wdt lub Packs.zip obok OpenTzar.exe i uruchom ponownie.")?;
            locate(candidates(&dir).collect()).ok_or("Wybrany folder nie zawiera oryginalnego images.wdt lub Packs.zip z polskiego wydania GOG.")?
        }
    };
    let archive = Archive::from_bytes(&bytes)?;
    let mut pictures = HashMap::new();
    for entry in &archive.entries {
        let key = archive::key(&entry.name);
        let Some(short) = key.strip_prefix("IMAGES/") else {continue};
        if short.starts_with("BUILDING/EURO ") || short.starts_with("BUILDING/MASK/EURO ")
            || short.starts_with("UNIT/EURO PEASANT") || short == "ICONS/ICONS.BMP" {
            pictures.insert(short.to_owned(), archive.read(entry)?);
        }
    }
    crate::write_atomic(&config, path.to_string_lossy().as_bytes())?;
    eprintln!("[TEST4] Europa: {} ({} zasobów), Słowianie: {}", path.display(), pictures.len(), source.display());
    let _ = PICTURES.set(pictures);
    Ok(())
}
