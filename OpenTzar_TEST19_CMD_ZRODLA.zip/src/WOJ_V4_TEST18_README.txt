OpenTzar TEST18 + Woj plemienny V4 (test)

Komplet źródeł na bazie przesłanego OpenTzar_TEST18_zrodla.zip. Nie jest to potwierdzony format manifestu OpenTzar Studio 0.3.1. Archiwum ma układ projektu jak eksport TEST18 (Cargo.toml w katalogu głównym). Użyć wyłącznie jeżeli Studio przyjmuje pełne źródła ZIP; jeżeli wymaga manifestu, potrzebna jest wzorcowa paczka aktualizacji gry lub kod aktualizatora. Nie instalować jako aktualizacji samego Studio.

Zmiany: cztery arkusze ciała woja plemiennego zastąpione V4, cztery arkusze cieni dodane, rejestracja cieni w src/army.rs i src/army/motion.ini. Pozostałe pliki TEST18 zachowane bajt w bajt. Nie zmieniano mechaniki, statystyk, czasów animacji, kotwic ani wersji Cargo.

Spoczynek: 8 zaakceptowanych widoków V3; chód E i SW, atak SW, śmierć SW z poprawkami V4; inne kierunki nadal robocze V3. Bez kompilacji i testów w Windows. Test w grze: rekrutacja, obrót 8 kierunków, chód, atak, śmierć, cień, kolory gracza, pozostałe jednostki.

Pliki zmienione/dodane:
art/army/tribal_attack.rle
art/army/tribal_attack_s.rle
art/army/tribal_die.rle
art/army/tribal_die_s.rle
art/army/tribal_idle.rle
art/army/tribal_idle_s.rle
art/army/tribal_walk.rle
art/army/tribal_walk_s.rle
src/army.rs
src/army/motion.ini

Walidacja RLE wg reguł src/sprite.rs (Python):
art/army/tribal_idle.rle: 64 klatek; fmt=1; count_ramp=6353; SHA256 e26c417e65742abc557818df91321f36b335e3e0042620f1661c2f15802e8979
art/army/tribal_idle_s.rle: 64 klatek; fmt=7; count_ramp=0; SHA256 81f64798c8dc1ebd620bc1e7505f2f4d06c6c5bac21ed828de3dfd70713b5295
art/army/tribal_walk.rle: 112 klatek; fmt=1; count_ramp=11766; SHA256 4d4d1422b6c6047c1a34480176afe5a01ad7f278fe8a4dac1c8582e72e6ba878
art/army/tribal_walk_s.rle: 112 klatek; fmt=7; count_ramp=0; SHA256 ec3aa5e65dfaa17c1f2feb19bdba3c802136c0943784a841889fc55695ac9056
art/army/tribal_attack.rle: 112 klatek; fmt=1; count_ramp=11427; SHA256 c6792a9e7afda62430eddf0e82db79349372146199794469cb8770fa9e2b04e9
art/army/tribal_attack_s.rle: 112 klatek; fmt=7; count_ramp=0; SHA256 864dce054a00ef658e62fcbc6f577961a919492cdeb38a7342844dfc70d19667
art/army/tribal_die.rle: 144 klatek; fmt=1; count_ramp=11211; SHA256 88d29df4da7c29d19babc69227e248039728a733da6b6b81d3b6a6aa75778c05
art/army/tribal_die_s.rle: 144 klatek; fmt=7; count_ramp=0; SHA256 a4186fabf54426a6caf2a58a87ec5a58dda068b28b503f745c24a6fd416882d9
