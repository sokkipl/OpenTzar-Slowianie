//! Registration of the project's replacement building sheets in map pixels.
use crate::bitmap::Bitmap;

/// Try the INI placement and small translations against the grey cloth
/// painted into the building. Keep the supplied placement on ambiguous art.
pub fn flag_offset(body: &Bitmap, mask: &Bitmap, origin: [i32; 2]) -> [i32; 2] {
    let samples: Vec<_> = mask.rgba.chunks_exact(4).enumerate()
        .filter(|(_,p)| p[3] != 0).step_by(8)
        .map(|(i,_)| ((i % mask.width as usize) as i32, (i / mask.width as usize) as i32)).collect();
    if samples.len() < 12 { return origin; }
    let score = |[dx,dy]: [i32;2]| samples.iter().filter(|&&(x,y)| {
        let (x,y)=(x+dx,y+dy);
        if x<0 || y<0 || x>=body.width as i32 || y>=body.height as i32 { return false; }
        let at=4*(y as usize*body.width as usize+x as usize);
        let p=&body.rgba[at..at+4];
        let hi=p[0].max(p[1]).max(p[2]);
        let lo=p[0].min(p[1]).min(p[2]);
        p[3]!=0 && hi>38 && hi-lo<=18
    }).count();
    let initial=score(origin);
    if initial*100 >= 94*samples.len() { return origin; }
    let mut best=(initial,origin);
    for y in -12..=12 { for x in -36..=36 {
        let offset=[origin[0]+x,origin[1]+y];
        let n=score(offset);
        if n>best.0 { best=(n,offset); }
    }}
    if best.0>=initial+samples.len()/10 {best.1} else {origin}
}

pub fn paint_mask(body: &mut Bitmap, mask: &Bitmap, [dx,dy]:[i32;2]) {
    for (i,p) in mask.rgba.chunks_exact(4).enumerate().filter(|(_,p)| p[3]!=0) {
        let x=dx+(i%mask.width as usize) as i32;
        let y=dy+(i/mask.width as usize) as i32;
        if x>=0 && y>=0 && x<body.width as i32 && y<body.height as i32 {
            let at=(y as usize*body.width as usize+x as usize)*4;
            body.rgba[at..at+4].copy_from_slice(p);
        }
    }
}

pub fn house_grid(w:usize,h:usize,cols:usize,rows:usize)->(usize,usize) {
    if h>=2*w && h%3==0 {(1,3)} else if w>=2*h && w%3==0 {(3,1)} else {(cols,rows)}
}

/// Approved building art, paired with a grayscale owner-colour mask.
pub struct BuildingArt {
    pub class: &'static str,
    pub sprite: &'static [u8],
    mask: &'static [u8],
}
macro_rules! building {
    ($name:literal) => { BuildingArt {
        class: $name,
        sprite: include_bytes!(concat!("../art/slavs/", $name, ".png")),
        mask: include_bytes!(concat!("../art/slavs/", $name, "_mask.png")),
    } }
}
pub static BUILDINGS: &[BuildingArt] = &[
    building!("academy"),
    building!("barrack"),
    building!("blacksmith"),
    building!("cathedral"),
    building!("church"),
    building!("farm"),
    building!("harbor"),
    building!("house"),
    building!("lumber"),
    building!("magetower"),
    building!("market"),
    building!("outpost"),
    building!("stable"),
    building!("storage"),
    building!("tavern"),
    building!("tcguild"),
    building!("workshop"),
];

impl BuildingArt {
    pub fn for_class(name: &str) -> Option<&'static Self> {
        BUILDINGS.iter().find(|art| art.class == name)
    }
    pub fn picture(&self, assets: &crate::assets::GameAssets, slot: Option<usize>) -> crate::Result<Bitmap> {
        let mut body = Bitmap::decode_png(self.sprite)?;
        if let Some(slot) = slot {
            let mask = Bitmap::decode_png(self.mask)?;
            let palette = assets.get("IMAGES/PALETTE.BMP")?;
            let start = 14 + crate::u32_at(&palette, 14)? as usize + 4 * (112 + 16 * slot.min(7));
            let ramp = palette.get(start..start + 64).ok_or("Invalid kingdom palette")?;
            for (p, m) in body.rgba.chunks_exact_mut(4).zip(mask.rgba.chunks_exact(4)) {
                if m[0] == 0 || p[3] == 0 { continue; }
                let light = (p[0] as usize + 2*p[1] as usize + p[2] as usize)/4;
                let offset = 4 * (3 + light / 10).min(15);
                let weight = m[0] as u32;
                for c in 0..3 {
                    p[c] = ((p[c] as u32 * (255-weight) + ramp[offset+2-c] as u32 * weight)/255) as u8;
                }
            }
        }
        Ok(body)
    }
}

pub fn livestock_picture(name: &str) -> Option<&'static [u8]> {
    if name.eq_ignore_ascii_case("IMAGES/slav_hen.bmp") {
        Some(include_bytes!("../art/slavs/hen.bmp"))
    } else if name.eq_ignore_ascii_case("IMAGES/slav_egg.bmp") {
        Some(include_bytes!("../art/slavs/egg.bmp"))
    } else {
        None
    }
}

pub fn farm_orders(a: &crate::assets::GameAssets) -> crate::Result<crate::assets::Ini> {
    let mut orders = crate::assets::Ini::parse(&a.get("DATA/ORDERS.INI")?);
    orders.set("hen", "action", "create hen".into());
    orders.set("hen", "classname", "hen".into());
    Ok(orders)
}
