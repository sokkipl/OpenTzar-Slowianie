use retzar::{Result, assets::GameAssets, world::{class, Kingdom, Layer, MapObject, MissionWorld, ObjectLibrary}};
use std::path::Path;
fn main() -> Result<()> {
    let args: Vec<_> = std::env::args().collect();
    let root=Path::new(&args[1]);
    retzar::europe::prepare(root, Path::new(&args[2]))?;
    let assets=GameAssets::open(root)?;
    let lib=ObjectLibrary::load(&assets,"SNOW")?;
    retzar::lang::set(retzar::lang::Language::Polish);
    let _skin = retzar::hud::HudSkin::load(&assets)?;
    for key in ["e_house", "e_lumber", "e_barrack"] {
        let picture = lib.effect_picture(&assets, key)?;
        assert!(picture.frames[0].rgba.chunks_exact(4).any(|p| p[3] > 0));
    }
    let classes=[class::CASTLE,class::CASTLE,class::CASTLE,class::BARRACK,class::BARRACK,class::PEON,class::PEON,class::HOUSE,class::HOUSE,class::HOUSE];
    let mut world=MissionWorld{kingdoms:(0..3).map(|i|Kingdom{color:i+1,active:true,..Default::default()}).collect(),..Default::default()};
    for (i,c) in classes.into_iter().enumerate(){
        world.objects.push(MapObject{class:c, civilization:if [0,3,5].contains(&i){1}else{4},owner:if i==2{3}else if [1,4,6].contains(&i){2}else{1},flags:0,health:100,max_health:100,data:vec![0;128],id:i as u16,x:8,y:8,variant:i.saturating_sub(7) as u16,name:String::new(),subtitle:String::new(),portrait:String::new(),portrait_large:String::new(),custom_image:String::new(),mole:0,control:[0;8],sight:[0;8]});
    }
    assert_eq!(lib.class_label(&world.objects[7]), "Chata");
    let mut european_house = world.objects[7].clone();
    european_house.civilization = 1;
    assert_ne!(lib.class_label(&european_house), "Chata");
    let start = world.objects.len();
    for art in retzar::slavic_art::BUILDINGS {
        let mut object = world.objects[4].clone();
        object.class = retzar::world::CLASSES.iter().position(|name| *name == art.class).unwrap();
        object.id = world.objects.len() as u16;
        world.objects.push(object);
    }
    let scene=lib.build_indices(&assets,&world,64,None)?;
    assert!(scene.missing.is_empty(),"{:?}",scene.missing);
    let body=|i|scene.visuals.iter().find(|v|v.object==i && v.layer==Layer::Body).unwrap();
    let image=|i|&scene.images[body(i).image];
    assert_ne!(image(0).width,image(1).width);
    let first=&scene.animations[body(1).animation.unwrap()];
    let second=&scene.animations[body(2).animation.unwrap()];
    assert_eq!(first.frames.len(),7);
    for (&a,&b) in first.frames.iter().zip(&second.frames){
        assert!(scene.images[a].rgba.chunks_exact(4).zip(scene.images[b].rgba.chunks_exact(4)).filter(|(x,y)|x!=y).count()>1000);
    }
    assert!(first.frames.windows(2).all(|pair|scene.images[pair[0]].rgba!=scene.images[pair[1]].rgba));
    let cells = lib.cell_footprint(&world.objects[4]);
    let [x,y] = world.objects[4].location();
    assert!(body(4).top_left[0] >= x && body(4).top_left[0] + image(4).width as f32 <= x + (32*cells[0]) as f32);
    assert!(body(4).top_left[1] <= y && body(4).top_left[1] - image(4).height as f32 >= y - (32*cells[1]) as f32);
    println!("Barracks {}x{} in {}x{} cells", image(4).width, image(4).height, cells[0], cells[1]);
    for (i,art) in retzar::slavic_art::BUILDINGS.iter().enumerate() {
        let index = start+i;
        let obj = &world.objects[index];
        let pic = image(index);
        let expected = art.picture(&assets, world.color_slot(obj.owner))?;
        let scaled = expected.resample(pic.width, pic.height);
        assert_eq!(pic.rgba, scaled.rgba, "Sprite mismatch: {}", art.class);
        let other = art.picture(&assets, Some(5))?;
        assert_ne!(expected.rgba,other.rgba,"Missing team colour: {}",art.class);
        println!("OK {} {}x{}", art.class, pic.width, pic.height);
    }
    assert_eq!(retzar::slavic_art::house_grid(96,288,3,1),(1,3));
    assert_eq!(retzar::slavic_art::house_grid(288,96,1,1),(3,1));
    // Offset the cloth deliberately to reproduce the doubled flag.
    let blank=|| retzar::bitmap::Bitmap {width:80,height:56,rgba:vec![0;80*56*4]};
    let mut base=blank();let mut mask=blank();
    for y in 12..29 {for x in 28..45 {
        base.rgba[4*(y*80+x)..4*(y*80+x)+4].copy_from_slice(&[88,88,88,255]);
        let q=4*(y*80+x+19); mask.rgba[q..q+4].copy_from_slice(&[0,0,200,255]);
    }}
    let off=retzar::slavic_art::flag_offset(&base,&mask,[0,0]);assert_eq!(off,[-19,0]);
    retzar::slavic_art::paint_mask(&mut base,&mask,off);
    assert!(!base.rgba.chunks_exact(4).any(|p|p==[88,88,88,255]));
    assert!(assets.get("IMAGES/EU_BASE/UNIT/EURO PEASANT IDLE.RLE").is_ok());
    println!("OK: ID1 castle {}px, ID4 castle {}px, seven animated frames for two owners, aligned flags and barracks, approved Slavic buildings, both workers rendered",image(0).width,image(1).width);
    Ok(())
}
